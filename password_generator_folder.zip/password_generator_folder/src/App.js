import React from 'react'
import AppFunction from './appFunction';


function App() {
  return (
    <div>
      <AppFunction />
    </div>
  )
}

export default App
